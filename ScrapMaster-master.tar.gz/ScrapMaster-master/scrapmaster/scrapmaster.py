import requests
import lxml
import json
from bs4 import BeautifulSoup as bSoup

## Main Function
def scrapGrid (jsonobject):
    jsonobject = json.loads(jsonobject)
    collection = []
    valid_input = validate_input(jsonobject)
    if valid_input != True:
        return json.dumps(valid_input)
    if jsonobject["type"] == "0":
        f = open(jsonobject["url"], encoding="utf8")     
        soup = bSoup(f,'lxml')
        f.close()
    else:
        soup = getSoup(jsonobject["url"])
    if soup == {"exception":{"code":"00","description":"There was a problem with the URL"}}:
        return json.dumps(soup)
    elementSet = getElementSet(soup,jsonobject["elementSet"]["etag"],jsonobject["elementSet"]["eclass"])
    if elementSet == []:
        return json.dumps({"exception":{"code":"06","description":"Not a valid grid element definition"}})
    for element in elementSet:
        elementDict = getElementDict(element, jsonobject["elementDef"])
        collection.append(elementDict)
    gridElements = {"gridElements":collection}
    return json.dumps(gridElements)

## scraping functions
def getSoup(url):
    try:
        response = requests.get(url)
        responseParsed = bSoup(response.text, 'lxml')
        return responseParsed
    except:
        return {"exception":{"code":"00","description":"There was a problem with the URL"}}

def getElementSet(mainSoup, tag, class_):
    elementSet = mainSoup.find_all(tag, class_=class_)
    return elementSet

def getElement (parent, tag, class_, isType, extract):
    if parent.find(tag, class_=class_) == None:
        return None
    else:
        if isType == '0':
            return cleanText(parent.find(tag, class_=class_).text)
        else:
            return parent.find(tag, class_=class_)[extract]

def getElementDict (elementSet, elementDef):
    elementDict = {}
    for element in elementDef:
        elementValue = getElement(elementSet,element['elementTag'],element['elementClass'],element['extractType'],element['elementExtract'])
        elementDict[element['elementName']] = elementValue
    return elementDict

## Pagination Functions
def getTotalPages(mainSoup):
    pagination = mainSoup.find('ul', class_='a-pagination')
    if pagination.find('li', class_='a-last') == None:
        return (None)
    else:
        lastPage = pagination.find('li', class_='a-last')
        totalPages = lastPage.a['href'][lastPage.a['href'].find('pg'):len(lastPage.a['href'])]
        linkStruct = lastPage.a['href'][0:lastPage.a['href'].find('pg')-1]
        numberPages = int(totalPages[totalPages.find('=')+1:len(totalPages)])
        return linkStruct, numberPages

def makeLinkCollection(mainSoup):
    linkCollection = []
    if getTotalPages(mainSoup) == None:
        return None
    else:
        for i in range(1,getTotalPages(mainSoup)[1]+1):
            linkCollection.append(getTotalPages(mainSoup)[0]+'&pg='+str(i))
        return(linkCollection)

## Utility functions for text manipulation

def getStringSection(string, start, stop):
        return string[string.find(start)+len(start):string.find(stop)]

def cleanText(string):
    string = string.replace('\n',"")
    string = string.replace('\r',"").strip()
    return string

# validation functions 
def validate_element (v_dict, v_dict_type):
    elementModel = [
                    {"type":"","url":"","elementSet":{},"elementDef":[]},
                    {"etag":"etag","eclass":"eclass"},
                    {"elementName":"Rank","elementTag":"span","elementClass":"zg-badge-text","extractType":"0","elementExtract":"text"},
                    ]
    def switchModel (v_dict_type):
        switcher = {
            "jsonObject":0,
            "elementSet":1,
            "elementDef":2
        }
        return switcher.get(v_dict_type)
    try: 
        if v_dict.keys() != elementModel[switchModel(v_dict_type)].keys():
            return {"exception":{"code":"01","description":"Dictionary Definition Error"}}
    except:
        return {"exception":{"code":"02","description":"Dictionary Expected"}}
    return True

def validate_input (jsonobject):
    if validate_element(jsonobject,"jsonObject") != True:
        return {"exception":{"code":"03","description":"Invalid Json Interface Defintion"}}
    if validate_element(jsonobject["elementSet"],"elementSet") != True:
       return {"exception":{"code":"04","description":"Invalid Element Set Defintion"}}
    for element in jsonobject["elementDef"]:
        if validate_element(element,"elementDef") != True:
            return {"exception":{"code":"05","description":"Invalid Element Defintion"}}
    return True