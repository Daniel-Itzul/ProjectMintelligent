import json
import unittest
from scrapmaster import scrapmaster
amazonPath = "scrapmaster/resources/amazondefinition.json" 
happyPath = "scrapmaster/resources/happyPath.json"
invalidURLPath = "scrapmaster/resources/invalidURL.json" 
invalidJsonPath = "scrapmaster/resources/invalidJson.json"
invalidElementSetPath = "scrapmaster/resources/invalidElementSet.json"
invalidDefinitionPath = "scrapmaster/resources/invalidDefinition.json"
invalidGridDefinitionPath = "scrapmaster/resources/invalidGridDefinition.json"

def openTestFile(path):
    with open(path, "r") as json_file:
        data=json_file.read()
    return data

def test(path):
    test = scrapmaster.scrapGrid(openTestFile(path))
    return test

class TestScrap(unittest.TestCase):
    def test_amazonPath(self):
        result = json.loads(test(amazonPath))
        self.assertGreater(len(result["gridElements"]),1)

    def test_happyPath(self):
        result = json.dumps({"gridElements": [{"Element1": "Element1", "Element2": "Element2"}, {"Element1": "Element1", "Element2": "Element2"}, {"Element1": "Element1", "Element2": "Element2"}]})
        self.assertEqual(test(happyPath),result)

    def test_invalidURL(self):
        result = json.dumps({"exception":{"code":"00","description":"There was a problem with the URL"}})
        self.assertEqual(test(invalidURLPath),result)
    
    def test_invalidJson(self):
        result = json.dumps({"exception":{"code":"03","description":"Invalid Json Interface Defintion"}})
        self.assertEqual(test(invalidJsonPath),result)

    def test_invalidElementSet(self):
        result = json.dumps({"exception":{"code":"04","description":"Invalid Element Set Defintion"}})
        self.assertEqual(test(invalidElementSetPath),result)
    
    def test_invalidDefinition(self):
        result = json.dumps({"exception":{"code":"05","description":"Invalid Element Defintion"}})
        self.assertEqual(test(invalidDefinitionPath),result)
    
    def test_invalidGridDefinition(self):
        result = json.dumps({"exception":{"code":"06","description":"Not a valid grid element definition"}})
        self.assertEqual(test(invalidGridDefinitionPath),result)