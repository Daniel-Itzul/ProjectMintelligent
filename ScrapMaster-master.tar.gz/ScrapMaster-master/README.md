# ScrapMaster
A multipurpose scrapper engine
